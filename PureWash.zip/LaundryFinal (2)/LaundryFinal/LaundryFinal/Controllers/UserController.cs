﻿using LaundryFinal.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace LaundryFinal.Controllers
{
    public class UserController : Controller
    {
        private readonly IHttpContextAccessor context;

        public UserController(IHttpContextAccessor httpContextAccessor)
        {
            context = httpContextAccessor;
        }

        // GET: UserController
        public ActionResult Register()
        {
            HttpContext.Session.Clear();
            return View();
        }

        // POST: UserController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register(User user)
        {
            try
            {
                DAO.Register(user.Name, user.Email, user.Password);
                return RedirectToAction(nameof(Login));
            }
            catch
            {
                return View();
            }
        }

        // GET: UserController
        public ActionResult Login()
        {
            //int ids = HttpContext.Session.GetInt32("UserId") ?? 0;
            return View();
        }

        // POST: UserController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(User user)
        {
            try
            {
                User users = DAO.Login(user.Email, user.Password);
                if (users != null)
                {
                    bool is_admin = users.is_admin;
                    HttpContext.Session.SetInt32("IsLoggedIn", 1);
                    HttpContext.Session.SetInt32("UserId", users.User_id);

                    if (is_admin)
                    {
                        return RedirectToAction("Index", "Admin");
                    }
                    ViewBag.Name = user.Name;
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    // User not found, set a TempData value to display the error message.
                    HttpContext.Session.SetInt32("IsLoggedIn", 0);
                    return RedirectToAction(nameof(Register));
                }
            }
            catch
            {
                return View();
            }
        }
    

    // GET: UserController
    public ActionResult Index()
        {
            int ids = HttpContext.Session.GetInt32("UserId") ?? 0;
            Console.WriteLine(ids);
            List<Order> orders = DAO.GetOrders(ids);
            return View(orders);
        }

        // GET: UserController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: UserController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: UserController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Order order)
        {
            try
            {
                int ids = HttpContext.Session.GetInt32("UserId") ?? 0;
                DAO.PlaceOrder(order.Shirts, order.Pants, order.Suits, order.Del_Address, ids);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: UserController/Edit/5
        // GET: UserController/Edit/5
        public ActionResult Edit(int id)
        {
            // Fetch the order information from the database based on the given 'id'
            Order order = DAO.GetOrder(id);

            // Check if the order exists
            if (order == null)
            {
                // Return a not-found error or redirect to an error page
                return NotFound();
            }

            // Pass the fetched 'Order' model to the 'Edit' view
            return View(order);
        }

        // POST: UserController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Order order)
        {
            try
            {
                // Update the order information in the database based on the 'order' model
                // and the given 'id'
                DAO.UpdateOrder(id, order);

                // Redirect to the 'Index' action after successful edit
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                // Handle the error appropriately, e.g., show an error message
                // or return the 'Edit' view again with the order model
                return View(order);
            }
        }


        // GET: UserController/Delete/5
        public ActionResult Delete(int id)
        {
            Order order = DAO.GetOrder(id);
            return View(order);
        }

        // POST: UserController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection, Order order)
        {
            try
            {
                Console.WriteLine(order.Order_Id);
                Console.WriteLine(order.Del_Address + "address");
                Console.WriteLine(id);
                DAO.cancelOrder(id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
