﻿using System;
using System.ComponentModel.DataAnnotations;

namespace LaundryFinal.Models
{
    public class User
    {
        [Required(ErrorMessage = "Name is required.")]
        [StringLength(10, MinimumLength = 3, ErrorMessage = "Name should atleast contain 3 alphabets.")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Name can only contain alphabets")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid email address.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        [StringLength(15, MinimumLength = 6, ErrorMessage = "Password must be at least 6 characters.")]
        public string Password { get; set; }

        public int User_id { get; set; }

        public bool is_admin { get; set; }

        public User() { }

        public User(string name, string email, string password, bool is_admin)
        {
            this.Name = name;
            this.Email = email;
            this.Password = password;
            this.is_admin = is_admin;
            Random random = new Random();
            this.User_id = random.Next(1000, 9999);
        }

        public User(string name, string email, string password, int User_id, bool is_admin)
        {
            this.Name = name;
            this.Email = email;
            this.Password = password;
            this.User_id = User_id;
            this.is_admin = is_admin;
        }
    }
}
