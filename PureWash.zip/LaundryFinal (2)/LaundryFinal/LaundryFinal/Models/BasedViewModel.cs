﻿namespace LaundryFinal.Models
{
    public class BasedViewModel
    {
        public bool IsLoggedIn { get; set; }
    }

}
